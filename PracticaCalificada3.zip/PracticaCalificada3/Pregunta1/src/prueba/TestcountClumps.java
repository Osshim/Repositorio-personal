package prueba;
import ejemplo.P1;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.swing.*;

import static org.junit.Assert.assertEquals;
public class TestcountClumps {
    @Test
    public void whenArrayisNullReturnZero(){
        int[] array = null;
        P1 p1 = new P1();
        assertEquals("El array es null", 0 ,p1.countClumps(array));

    }
    @Test
    public void whenArrayisNotLengthGreaterThanZeroReturnszero(){
        int[] array = {};
        P1 p1 = new P1();
        assertEquals("El array no tiene longitud mayor a 0", 0 ,p1.countClumps(array));

    }
    @Test
    public void whenArrayitLengthGreaterThanZeroReturnszero(){
        int[] array = {1,1,2,2,3,6,5,4,4,4};
        P1 p1 = new P1();
        assertEquals("El array tiene longitud mayor a 0", 3 ,p1.countClumps(array));

    }

}
